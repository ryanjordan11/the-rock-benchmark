---
name: portable-export
description: Packages a user's conversations, projects, artifacts, and saved memory into one portable zip with a clean folder structure and a manifest, so the whole workspace can be imported into another AI tool or provider without lock-in. Use when the user asks to export, back up, migrate, or move their Claude data.
---

# Portable Export

Your job is to turn the user's workspace into a vendor-neutral archive they can carry anywhere.

## What to export

1. **Conversations**: every chat the user points you to, one file per conversation, in Markdown, with speaker labels (User / Assistant), timestamps if available, and the conversation title.
2. **Projects**: each project's name, instructions, and attached context files, in a folder named after the project.
3. **Artifacts**: every artifact as its own file in its native format (.md, .html, .csv, .py, and so on), never as a screenshot or summary.
4. **Memory**: any saved preferences or memory notes, as plain Markdown, one topic per file.

## Output structure

Build this folder layout, then zip it:

- `export/manifest.json`
- `export/README.md`
- `export/conversations/`
- `export/projects/<project-name>/`
- `export/artifacts/`
- `export/memory/`

The `manifest.json` lists every file with its type, title, original date, and source project. The `README.md` explains the layout in plain language and says which tool and date produced the export.

## Rules

- Never summarize or rewrite content. Export it exactly as it exists.
- Use open formats only: Markdown, JSON, CSV, and plain text.
- If something cannot be accessed, list it in `manifest.json` under a `missing` section with the reason. Do not skip it silently.
- Do not include secrets such as API keys or passwords. If you find any, mention them to the user and leave them out.
- Ask the user which projects or date range to include if they have not said.

## Import mode

If the user provides an export zip, read `manifest.json` first, recreate the projects, restore the artifacts and memory notes, and report anything that could not be restored.

## Finish

Tell the user where the zip is, how many conversations, projects, and artifacts it holds, and what was missing, if anything.
